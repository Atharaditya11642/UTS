package com.example.aplikasimenumakanan;

public class item {
    private String nama;
    private String harga;
    private String link;

    public String getNama() {
        return nama;
    }
    public String getHarga() {
        return harga;
    }
    public String getLink() {
        return link;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public void setLink(String link) {
        this.link = link;
    }

}
